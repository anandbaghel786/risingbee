export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCqTb8C-9zwbSXDQ9L1P6EeCu0-2caHYiI",
    authDomain: "angular-man-9d1b6.firebaseapp.com",
    databaseURL: "https://angular-man-9d1b6.firebaseio.com",
    projectId: "angular-man-9d1b6",
    storageBucket: "angular-man-9d1b6.appspot.com",
    messagingSenderId: "394292264236",
    appId: "1:394292264236:web:ce80b9bd892f6abb2a4089",
    measurementId: "G-PN6B39RKRY"
  }
};
